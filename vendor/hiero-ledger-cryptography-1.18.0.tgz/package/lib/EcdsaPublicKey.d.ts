/**
 * A public key on the Hedera™ network.
 */
export default class EcdsaPublicKey extends Key {
    /**
     * @param {Uint8Array} data
     * @returns {EcdsaPublicKey}
     */
    static fromBytes(data: Uint8Array): EcdsaPublicKey;
    /**
     * @param {Uint8Array} data
     * @returns {EcdsaPublicKey}
     */
    static fromBytesDer(data: Uint8Array): EcdsaPublicKey;
    /**
     * @param {Uint8Array} data
     * @returns {EcdsaPublicKey}
     */
    static fromBytesRaw(data: Uint8Array): EcdsaPublicKey;
    /**
     * Parse a public key from a hexadecimal string.
     *
     * The public key may optionally be prefixed with
     * the DER header.
     * @param {string} text
     * @returns {EcdsaPublicKey}
     */
    static fromString(text: string): EcdsaPublicKey;
    /**
     * @internal
     * @hideconstructor
     * @param {Uint8Array} keyData
     */
    constructor(keyData: Uint8Array);
    /**
     * @type {Uint8Array}
     * @private
     * @readonly
     */
    private readonly _keyData;
    /**
     * @returns {string}
     */
    get _type(): string;
    /**
     * Verify a signature on a message with this public key.
     * @param {Uint8Array} message
     * @param {Uint8Array} signature
     * @returns {boolean}
     */
    verify(message: Uint8Array, signature: Uint8Array): boolean;
    /**
     * @returns {Uint8Array}
     */
    toBytesDer(): Uint8Array;
    /**
     * @returns {Uint8Array}
     */
    toBytesRaw(): Uint8Array;
    /**
     * @returns {string}
     */
    toEthereumAddress(): string;
    /**
     * @param {EcdsaPublicKey} other
     * @returns {boolean}
     */
    equals(other: EcdsaPublicKey): boolean;
}
import Key from "./Key.js";
