export default class Key {
}
