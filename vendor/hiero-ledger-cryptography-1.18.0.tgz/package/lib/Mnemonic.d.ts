export const HARDENED: 2147483648;
export const HEDERA_PATH: number[];
export const SLIP44_ECDSA_HEDERA_PATH: number[];
export const SLIP44_ECDSA_ETH_PATH: number[];
/**
 * Multi-word mnemonic phrase (BIP-39).
 *
 * Compatible with the official Hedera mobile
 * wallets (24-words or 22-words) and BRD (12-words).
 */
export default class Mnemonic {
    /**
     * Returns a new random 24-word mnemonic from the BIP-39
     * standard English word list.
     * @returns {Promise<Mnemonic>}
     */
    static generate(): Promise<Mnemonic>;
    /**
     * Returns a new random 12-word mnemonic from the BIP-39
     * standard English word list.
     * @returns {Promise<Mnemonic>}
     */
    static generate12(): Promise<Mnemonic>;
    /**
     * @param {number} length
     * @returns {Promise<Mnemonic>}
     */
    static _generate(length: number): Promise<Mnemonic>;
    /**
     * Construct a mnemonic from a list of words. Handles 12, 22 (legacy), and 24 words.
     *
     * An exception of BadMnemonicError will be thrown if the mnemonic
     * contains unknown words or fails the checksum. An invalid mnemonic
     * can still be used to create private keys, the exception will
     * contain the failing mnemonic in case you wish to ignore the
     * validation error and continue.
     * @param {string[]} words
     * @throws {BadMnemonicError}
     * @returns {Promise<Mnemonic>}
     */
    static fromWords(words: string[]): Promise<Mnemonic>;
    /**
     * @param {string[]} words
     * @param {string} passphrase
     * @returns {Promise<Uint8Array>}
     */
    static toSeed(words: string[], passphrase: string): Promise<Uint8Array>;
    /**
     * Recover a mnemonic phrase from a string, splitting on spaces. Handles 12, 22 (legacy), and 24 words.
     * @param {string} mnemonic
     * @returns {Promise<Mnemonic>}
     */
    static fromString(mnemonic: string): Promise<Mnemonic>;
    /**
     * @param {object} props
     * @param {string[]} props.words
     * @throws {BadMnemonicError}
     * @hideconstructor
     * @private
     */
    private constructor();
    words: string[];
    /**
     * @deprecated - Use `toStandardEd25519PrivateKey()` or `toStandardECDSAsecp256k1PrivateKey()` instead
     * Recover a private key from this mnemonic phrase, with an
     * optional passphrase.
     * @param {string} [passphrase]
     * @returns {Promise<PrivateKey>}
     */
    toPrivateKey(passphrase?: string): Promise<PrivateKey>;
    /**
     * @deprecated - Use `toStandardEd25519PrivateKey()` or `toStandardECDSAsecp256k1PrivateKey()` instead
     * Recover an Ed25519 private key from this mnemonic phrase, with an
     * optional passphrase.
     * @param {string} [passphrase]
     * @param {number[]} [path]
     * @returns {Promise<PrivateKey>}
     */
    toEd25519PrivateKey(passphrase?: string, path?: number[]): Promise<PrivateKey>;
    /**
     * Recover an Ed25519 private key from this mnemonic phrase, with an
     * optional passphrase.
     * @param {string} [passphrase]
     * @param {number} [index]
     * @returns {Promise<PrivateKey>}
     */
    toStandardEd25519PrivateKey(passphrase?: string, index?: number): Promise<PrivateKey>;
    /**
     * @deprecated - Use `toStandardEd25519PrivateKey()` or `toStandardECDSAsecp256k1PrivateKey()` instead
     * Recover an ECDSA private key from this mnemonic phrase, with an
     * optional passphrase.
     * @param {string} [passphrase]
     * @param {number[]} [path]
     * @returns {Promise<PrivateKey>}
     */
    toEcdsaPrivateKey(passphrase?: string, path?: number[]): Promise<PrivateKey>;
    /**
     * Recover an ECDSA private key from this mnemonic phrase, with an
     * optional passphrase.
     * @param {string} [passphrase]
     * @param {number} [index]
     * @returns {Promise<PrivateKey>}
     */
    toStandardECDSAsecp256k1PrivateKey(passphrase?: string, index?: number): Promise<PrivateKey>;
    /**
     * @param {string} passphrase
     * @param {string} seedText
     * @returns {Promise<{ keyData: Uint8Array; chainCode: Uint8Array }>} seedText
     */
    _toKeyData(passphrase: string, seedText: string): Promise<{
        keyData: Uint8Array;
        chainCode: Uint8Array;
    }>;
    /**
     * @returns {Promise<Mnemonic>}
     * @private
     */
    private _validate;
    /**
     * @returns {Promise<PrivateKey>}
     */
    toLegacyPrivateKey(): Promise<PrivateKey>;
    /**
     * @returns {string}
     */
    toString(): string;
}
import PrivateKey from "./PrivateKey.js";
