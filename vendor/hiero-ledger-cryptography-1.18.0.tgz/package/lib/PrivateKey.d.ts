/**
 * @typedef {object} ProtoSignaturePair
 * @property {(Uint8Array | null)=} pubKeyPrefix
 * @property {(Uint8Array | null)=} ed25519
 * @property {(Uint8Array | null)=} ECDSASecp256k1
 */
/**
 * @typedef {object} ProtoSigMap
 * @property {(ProtoSignaturePair[] | null)=} sigPair
 */
/**
 * @typedef {object} ProtoSignedTransaction
 * @property {(Uint8Array | null)=} bodyBytes
 * @property {(ProtoSigMap | null)=} sigMap
 */
/**
 * @typedef {object} Transaction
 * @property {() => boolean} isFrozen
 * @property {ProtoSignedTransaction[]} _signedTransactions
 * @property {Set<string>} _signerPublicKeys
 * @property {(publicKey: PublicKey, signature: Uint8Array) => Transaction} addSignature
 * @property {() => void} _requireFrozen
 * @property {() => Transaction} freeze
 */
/**
 * @typedef {import("./Mnemonic.js").default} Mnemonic
 */
/**
 * A private key on the Hedera™ network.
 */
export default class PrivateKey extends Key {
    /**
     * Generate a random Ed25519 private key.
     * @returns {PrivateKey}
     */
    static generateED25519(): PrivateKey;
    /**
     * Generate a random EDSA private key.
     * @returns {PrivateKey}
     */
    static generateECDSA(): PrivateKey;
    /**
     * Depredated - Use `generateED25519()` instead
     * Generate a random Ed25519 private key.
     * @returns {PrivateKey}
     */
    static generate(): PrivateKey;
    /**
     * Depredated - Use `generateED25519Async()` instead
     * Generate a random Ed25519 private key.
     * @returns {Promise<PrivateKey>}
     */
    static generateAsync(): Promise<PrivateKey>;
    /**
     * Generate a random Ed25519 private key.
     * @returns {Promise<PrivateKey>}
     */
    static generateED25519Async(): Promise<PrivateKey>;
    /**
     * Generate a random ECDSA private key.
     * @returns {Promise<PrivateKey>}
     */
    static generateECDSAAsync(): Promise<PrivateKey>;
    /**
     * Construct a private key from bytes. Requires DER header.
     * @param {Uint8Array} data
     * @returns {PrivateKey}
     */
    static fromBytes(data: Uint8Array): PrivateKey;
    /**
     * Construct a ECDSA private key from bytes.
     * @param {Uint8Array} data
     * @returns {PrivateKey}
     */
    static fromBytesECDSA(data: Uint8Array): PrivateKey;
    /**
     * Construct a ED25519 private key from bytes.
     * @param {Uint8Array} data
     * @returns {PrivateKey}
     */
    static fromBytesED25519(data: Uint8Array): PrivateKey;
    /**
     * Construct a private key from a hex-encoded string. Requires DER header.
     * @param {string} text
     * @returns {PrivateKey}
     */
    static fromString(text: string): PrivateKey;
    /**
     * Construct a ECDSA private key from a hex-encoded string.
     * @param {string} text
     * @returns {PrivateKey}
     */
    static fromStringECDSA(text: string): PrivateKey;
    /**
     * Construct a Ed25519 private key from a hex-encoded string.
     * @param {string} text
     * @returns {PrivateKey}
     */
    static fromStringED25519(text: string): PrivateKey;
    /**
     * Construct a Ed25519 private key from a Uint8Array seed.
     * @param {Uint8Array} seed
     * @returns {Promise<PrivateKey>}
     */
    static fromSeedED25519(seed: Uint8Array): Promise<PrivateKey>;
    /**
     * Construct a ECDSA private key from a Uint8Array seed.
     * @param {Uint8Array} seed
     * @returns {Promise<PrivateKey>}
     */
    static fromSeedECDSAsecp256k1(seed: Uint8Array): Promise<PrivateKey>;
    /**
     * @deprecated - Use `Mnemonic.from[Words|String]().toStandard[Ed25519|ECDSAsecp256k1]PrivateKey()` instead
     *
     * Recover a private key from a mnemonic phrase (and optionally a password).
     * @param {Mnemonic | string} mnemonic
     * @param {string} [passphrase]
     * @returns {Promise<PrivateKey>}
     */
    static fromMnemonic(mnemonic: Mnemonic | string, passphrase?: string): Promise<PrivateKey>;
    /**
     * Recover a private key from a keystore, previously created by `.toKeystore()`.
     *
     * This key will _not_ support child key derivation.
     * @param {Uint8Array} data
     * @param {string} [passphrase]
     * @returns {Promise<PrivateKey>}
     * @throws {BadKeyError} If the passphrase is incorrect or the hash fails to validate.
     */
    static fromKeystore(data: Uint8Array, passphrase?: string): Promise<PrivateKey>;
    /**
     * Recover a private key from a pem string; the private key may be encrypted.
     *
     * This method assumes the .pem file has been converted to a string already.
     *
     * If `passphrase` is not null or empty, this looks for the first `ENCRYPTED PRIVATE KEY`
     * section and uses `passphrase` to decrypt it; otherwise, it looks for the first `PRIVATE KEY`
     * section and decodes that as a DER-encoded  private key.
     * @param {string} data
     * @param {string} [passphrase]
     * @returns {Promise<PrivateKey>}
     */
    static fromPem(data: string, passphrase?: string): Promise<PrivateKey>;
    /**
     * @hideconstructor
     * @internal
     * @param {Ed25519PrivateKey | EcdsaPrivateKey} key
     */
    constructor(key: Ed25519PrivateKey | EcdsaPrivateKey);
    /**
     * @type {Ed25519PrivateKey | EcdsaPrivateKey}
     * @readonly
     * @private
     */
    private readonly _key;
    /**
     * @returns {string}
     */
    get _type(): string;
    /**
     * @returns {Uint8Array | null}
     */
    get _chainCode(): Uint8Array | null;
    /**
     * Derive a new private key at the given wallet index.
     *
     * Only currently supported for keys created with from mnemonics; other keys will throw
     * an error.
     *
     * You can check if a key supports derivation with `.supportsDerivation()`
     * @param {number} index
     * @returns {Promise<PrivateKey>}
     * @throws If this key does not support derivation.
     */
    derive(index: number): Promise<PrivateKey>;
    /**
     * @param {number} index
     * @returns {Promise<PrivateKey>}
     * @throws If this key does not support derivation.
     */
    legacyDerive(index: number): Promise<PrivateKey>;
    /**
     * Get the public key associated with this private key.
     *
     * The public key can be freely given and used by other parties to verify
     * the signatures generated by this private key.
     * @returns {PublicKey}
     */
    get publicKey(): PublicKey;
    /**
     * Sign a message with this private key.
     * @param {Uint8Array} bytes
     * @returns {Uint8Array} - The signature bytes without the message
     */
    sign(bytes: Uint8Array): Uint8Array;
    /**
     * @param {Transaction} transaction
     * @returns {Uint8Array}
     */
    signTransaction(transaction: Transaction): Uint8Array;
    /**
     * Check if `derive` can be called on this private key.
     *
     * This is only the case if the key was created from a mnemonic.
     * @returns {boolean}
     */
    isDerivable(): boolean;
    /**
     * @returns {Uint8Array}
     */
    toBytes(): Uint8Array;
    /**
     * @returns {Uint8Array}
     */
    toBytesDer(): Uint8Array;
    /**
     * @returns {Uint8Array}
     */
    toBytesRaw(): Uint8Array;
    /**
     * @returns {string}
     */
    toStringDer(): string;
    /**
     * @returns {string}
     */
    toStringRaw(): string;
    /**
     * Create a keystore with a given passphrase.
     *
     * The key can be recovered later with `fromKeystore()`.
     *
     * Note that this will not retain the ancillary data used for
     * deriving child keys, thus `.derive()` on the restored key will
     * throw even if this instance supports derivation.
     * @param {string} [passphrase]
     * @returns {Promise<Uint8Array>}
     */
    toKeystore(passphrase?: string): Promise<Uint8Array>;
    /**
     * Recover the recovery ID used in the signature for the given message.
     *
     * **Note:** This method only works for ECDSA secp256k1 keys.
     * @param {Uint8Array} r - 32-byte `r` component of the signature
     * @param {Uint8Array} s - 32-byte `s` component of the signature
     * @param {Uint8Array} message - The original (unhashed) message
     * @returns {number} Recovery ID (0–3), or -1 if not found or not applicable
     */
    getRecoveryId(r: Uint8Array, s: Uint8Array, message: Uint8Array): number;
}
export type ProtoSignaturePair = {
    pubKeyPrefix?: (Uint8Array | null) | undefined;
    ed25519?: (Uint8Array | null) | undefined;
    ECDSASecp256k1?: (Uint8Array | null) | undefined;
};
export type ProtoSigMap = {
    sigPair?: (ProtoSignaturePair[] | null) | undefined;
};
export type ProtoSignedTransaction = {
    bodyBytes?: (Uint8Array | null) | undefined;
    sigMap?: (ProtoSigMap | null) | undefined;
};
export type Transaction = {
    isFrozen: () => boolean;
    _signedTransactions: ProtoSignedTransaction[];
    _signerPublicKeys: Set<string>;
    addSignature: (publicKey: PublicKey, signature: Uint8Array) => Transaction;
    _requireFrozen: () => void;
    freeze: () => Transaction;
};
export type Mnemonic = import("./Mnemonic.js").default;
import Key from "./Key.js";
import PublicKey from "./PublicKey.js";
import Ed25519PrivateKey from "./Ed25519PrivateKey.js";
import EcdsaPrivateKey from "./EcdsaPrivateKey.js";
