/**
 * @param {string} pem
 * @param {string} [passphrase]
 * @returns {Promise<Ed25519PrivateKey | EcdsaPrivateKey | Uint8Array>}
 */
export function readPemED25519(pem: string, passphrase?: string): Promise<Ed25519PrivateKey | EcdsaPrivateKey | Uint8Array>;
/**
 * @param {string} pem
 * @param {string} [passphrase]
 * @returns {Promise<Ed25519PrivateKey | EcdsaPrivateKey | Uint8Array>}
 */
export function readPemECDSA(pem: string, passphrase?: string): Promise<Ed25519PrivateKey | EcdsaPrivateKey | Uint8Array>;
/**
 * @param {string} pem
 * @param {string} [passphrase]
 * @returns {Promise<Ed25519PrivateKey | EcdsaPrivateKey | Uint8Array>}
 */
export function read(pem: string, passphrase?: string): Promise<Ed25519PrivateKey | EcdsaPrivateKey | Uint8Array>;
import Ed25519PrivateKey from "../Ed25519PrivateKey.js";
import EcdsaPrivateKey from "../EcdsaPrivateKey.js";
